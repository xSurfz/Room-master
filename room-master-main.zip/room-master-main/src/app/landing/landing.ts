import { Component } from '@angular/core';
import { LoginComponent } from '../login/login';
import { ModalService } from '@developer-partners/ngx-modal-dialog';
import { RouterOutlet } from '@angular/router';
@Component({
  selector: 'landing',
  standalone: true,
  templateUrl: './landing.html',
  styleUrl: './landing.css',
  imports: [
    LoginComponent,
    RouterOutlet,
  ],
})

export class LandingComponent {
  public buttonClick = false;
  public openModal(): void {
    this.buttonClick = true;
    this._modalService.show(LoginComponent, { title: 'Login' });
  }

  constructor(private readonly _modalService: ModalService) { 
        
  }
}
