import { Component } from "@angular/core";
import { FormGroup, FormControl, Validators, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { NgFor } from "@angular/common";

@Component({
    selector: 'register',
    standalone: true,
    templateUrl: './register.html',
    styleUrl: './register.css',
    imports: [
        ReactiveFormsModule, 
        HttpClientModule,
        NgFor,
        FormsModule
    ]
})
export class RegisterComponent {
    areas: any[] = [];

    registerForm = new FormGroup({
        fullName: new FormControl(''),
        email: new FormControl(''),
        password: new FormControl(''),
        confirmPassword: new FormControl(''),
        workArea: new FormControl(''),
        phone: new FormControl(''),
    });

    constructor(private http: HttpClient) {
        this.http.get<any[]>("http://localhost:3000/api/area_trabajo").subscribe(
            (response) => {
                this.areas = response;
                console.log('Áreas recibidas:', this.areas);
            },
            (error) => {
                console.error("Fallo al momento de cargar las áreas", error);
            }
        );
    }

    
    get passwordsMatch() {
        return this.registerForm.get('password')?.value === this.registerForm.get('confirmPassword')?.value;
    }

    public onSubmit() {
        if (this.registerForm.valid && this.passwordsMatch) {
            const userData = this.registerForm.value;
            console.log(this.registerForm.value);

            this.http.post('http://localhost:3000/api/register', userData).subscribe(
                response => {
                    console.log('Registro exitoso:', response);
                },
                error => {
                    console.error('Error en el registro:', error);
                }
            );
        } else {

            //Agregar ventana de error ajsdjasjdsa
            console.log('Las contraseñas no coinciden');
        }
    }
}
