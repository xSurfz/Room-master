import { Component } from '@angular/core';
import { ModalService } from '@developer-partners/ngx-modal-dialog';

@Component({
    selector: 'dashboard',
    standalone: true,
    templateUrl: './dashboard.html',
    styleUrl: './dashboard.css',
    imports: [],
})

export class DashboarComponent {
    public buttonClick = false;

    constructor(private readonly _modalService: ModalService) { 
            
    }
}
