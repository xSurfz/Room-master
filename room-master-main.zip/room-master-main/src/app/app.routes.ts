import { Routes, RouterModule } from '@angular/router';
import { DashboarComponent } from './dashboard/dashboard';
import { NgModule } from '@angular/core';

export const routes: Routes = [
    { path: 'dashboard', component: DashboarComponent },
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})

export class AppRoutingModule {}