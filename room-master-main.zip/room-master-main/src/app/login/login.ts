import { Component } from "@angular/core";
import { FormGroup, FormControl,FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ModalService } from '@developer-partners/ngx-modal-dialog';
import { RegisterComponent } from "../register/register";
import { Router } from "@angular/router";

@Component({
    selector: 'login',
    standalone: true,
    templateUrl: './login.html',
    styleUrl: './login.css',
    imports: [
        FormsModule,
        ReactiveFormsModule,
    ]
})

export class LoginComponent {
    constructor(
        private readonly _modalService: ModalService, 
        private readonly router: Router
    ){}

    loginForm = new FormGroup({
        email: new FormControl(''),
        password: new FormControl(''),
    })

    public openModal(): void {
        this._modalService.show(RegisterComponent, { title: 'Login' });
    }

    public onSubmit() {
        this.router.navigate(['/dashboard']);
    }

    public navigateToDashboard() {
        this.router.navigate(['/dashboard']);
    }

}