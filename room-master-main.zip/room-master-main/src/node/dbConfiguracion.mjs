import readline from 'readline';
import { db } from './server.mjs';

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

export function pedirDatos() {
    return new Promise((resolve) => {
        rl.question('Introduce el valor de la variable host: ', (host) => {
            rl.question('Introduce el valor de la variable user: ', (user) => {
                rl.question('Introduce el valor de la variable password: ', (password) => {
                    rl.question('Introduce el valor de la variable database: ', (database) => {
                        resolve({ host, user, password, database });
                        rl.close(); 
                    });
                });
            });
        });
    });
}

export async function Register(req, res) {
    const { fullName, mail, password, workArea, phone } = req.body;

    try {
        const codigo_area = await Codigo_area_trabajo(workArea); 
        console.log("Datos recibidos del formulario:");
        console.log("Full Name:", fullName);
        console.log("Email:", mail);
        console.log("Password:", password);
        console.log("Work Area:", codigo_area);
        console.log("Phone:", phone);

        
        db.query('INSERT INTO usuario (nombre, correo, contraseña, codigo_area_trabajo, telefono, Actividad) VALUES (?, ?, ?, ?, ?, ?)', 
            [fullName, mail, password, codigo_area, phone, true], 
            (error, results) => {
                if (error) {
                    console.error('Error al insertar datos en usuarios_input:', error);
                    return res.status(500).json('Error al registrar usuario');
                }
                
                res.status(200).json('Usuario registrado correctamente');
            }
        );
    } catch (error) {
        console.error('Error al registrar usuario:', error);
        res.status(500).json('Error al registrar usuario');
    }
}

export async function Login(req, res) {
    
}

export function Areas_trabajo(req, res) {
    const query = 'SELECT Nombre FROM areas_trabajo';
    
    db.query(query, (error, results) => {
        if (error) {
            console.error('Error al obtener las áreas de trabajo:', error);
            return res.status(500).send('Error al obtener las áreas de trabajo');
        }

        if (!Array.isArray(results) || results.length === 0) {
            return res.status(404).send('No se encontraron áreas de trabajo');
        }
        
        res.json(results);
    });
}

async function Codigo_area_trabajo(Nombre) {
    const query = 'SELECT Codigo FROM areas_trabajo WHERE Nombre = ?';

    return new Promise((resolve, reject) => {
        db.query(query, [Nombre], (error, results) => {
            if (error) {
                console.error('Error al ejecutar la consulta:', error);
                return reject(error);
            }

            if (results.length > 0) {
                resolve(results[0].Codigo);
            } else {
                resolve(null); 
            }
        });
    });
}
