import express from 'express';
import bodyParser from 'body-parser';
import cors from 'cors';
import mysql from 'mysql2';
import { pedirDatos, Login, Register, Areas_trabajo } from './dbConfiguracion.mjs'; 

const app = express();
const PORT = process.env.PORT || 3000;
export let db;

app.use(cors({
    origin: 'http://localhost:4200' 
}));

app.use(bodyParser.json());


// Iniciar antes de todo (revisar dependecias y MySql)
//
pedirDatos().then((datos) => {
    const connection = mysql.createConnection({
        host: datos.host,
        user: datos.user,
        password: datos.password,
        database: datos.database
    });

    connection.connect(err => {
        if (err) {
            console.error('Error conectando a la base de datos:', err);
            return;
        }
        console.log('Conectado a la base de datos MySQL');
        
        db = connection; 

        //rutas
        app.post("/api/register", Register);
        app.post("/api/login", Login);
        app.get("/api/area_trabajo", Areas_trabajo);







        app.listen(PORT, () => {
            console.log(`Servidor corriendo en http://localhost:${PORT}`);
        });
    });
}).catch((error) => {
    console.error('Error al obtener los datos:', error);
});
